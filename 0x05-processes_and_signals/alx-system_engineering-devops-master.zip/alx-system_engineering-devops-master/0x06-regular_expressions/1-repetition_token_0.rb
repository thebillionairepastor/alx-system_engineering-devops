#!/usr/bin/env ruby
puts ARGV[0].match(/hbt{2,5}n/)
