#!/bin/bash
1st script
\n
2nd script
\n
