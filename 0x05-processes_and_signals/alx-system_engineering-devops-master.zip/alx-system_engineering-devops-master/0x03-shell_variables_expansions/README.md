Shell Variables Expansions
